package com.tls.camel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamelRestDslApplication {

	public static void main(String[] args) {
		SpringApplication.run(CamelRestDslApplication.class, args);
	}
}
